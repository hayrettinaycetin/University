my_dict = {'Theodore': 19, 'Roxanne': 20, 'Mathew': 21, 'Betty': 20}

for x, y in my_dict.items():
  if y == 20:
    print(x)
  else:
    pass  


