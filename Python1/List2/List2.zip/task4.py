import numpy as np

list_1 = set([1,3,5,1,3,7,9])
list_2 = set([2,4,2,6,4,8])

array_1 = np.array(list_1)

array_2 = np.array(list_2)

print("First array: ", array_1)
print("Second array: ", array_2)



        

            